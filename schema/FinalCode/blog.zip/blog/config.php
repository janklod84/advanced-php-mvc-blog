<?php

return [
    'server'    => 'localhost',
    'dbname'    => 'blog',
    'dbuser'    => 'root',
    'dbpass'    => '',
];